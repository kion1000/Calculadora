/**
 * 
 */
/**
 * 
 */
module monedas {
	requires java.desktop;
}