package monedas;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import javax.swing.JLabel;

public class cambioMonedas extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField importeCambiar;
	private JTextField importeCambiado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cambioMonedas frame = new cambioMonedas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public cambioMonedas() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 325, 492);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		//Para que el programa se ejecute en el centro de la pantalla.
		setLocationRelativeTo (null);
		
		
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		importeCambiar = new JTextField();
		importeCambiar.setHorizontalAlignment(SwingConstants.RIGHT);
		importeCambiar.setForeground(new Color(254, 255, 255));
		importeCambiar.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		importeCambiar.setBackground(new Color(0, 0, 0));
		importeCambiar.setBounds(16, 51, 288, 73);
		contentPane.add(importeCambiar);
		importeCambiar.setColumns(10);
		
		importeCambiado = new JTextField();
		importeCambiado.setHorizontalAlignment(SwingConstants.RIGHT);
		importeCambiado.setForeground(new Color(254, 255, 255));
		importeCambiado.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		importeCambiado.setBackground(new Color(0, 0, 0));
		importeCambiado.setColumns(10);
		importeCambiado.setBounds(16, 184, 288, 73);
		contentPane.add(importeCambiado);
		
		JButton botonDolar = new JButton("DOLAR");
		botonDolar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int valorImporteCambiar;
				double valorImporteCambiado;
				double valordolar=1.09;
				String input=importeCambiar.getText();
				
				if (input.matches("\\d+")) {
					valorImporteCambiar=Integer.parseInt(input);
					valorImporteCambiado=valorImporteCambiar*valordolar;
					importeCambiado.setText(String.format("%.2f",valorImporteCambiado)+ " Dolares ");
				}else {
					importeCambiado.setText("Ingrese un Importe Valido ");
				}
			}
		});
		botonDolar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		botonDolar.setBounds(16, 282, 130, 43);
		contentPane.add(botonDolar);
		
		JButton botonRublos = new JButton("RUBLOS");
		botonRublos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		botonRublos.setBounds(174, 282, 130, 43);
		contentPane.add(botonRublos);
		
		JButton botonLibras = new JButton("LIBRAS");
		botonLibras.setBounds(16, 337, 130, 43);
		contentPane.add(botonLibras);
		
		JButton botonYenes = new JButton("YENES");
		botonYenes.setBounds(174, 337, 130, 43);
		contentPane.add(botonYenes);
		
		JLabel añadirImporte = new JLabel("AÑADIR IMPORTE €");
		añadirImporte.setBounds(179, 13, 125, 26);
		contentPane.add(añadirImporte);
		
		JLabel cambio = new JLabel("CAMBIO");
		cambio.setBounds(246, 136, 130, 36);
		contentPane.add(cambio);
		
		JButton botonLimpiar = new JButton("LIMPIAR");
		botonLimpiar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				importeCambiar.setText ("");
				importeCambiado.setText("");
				
			}
		});
		botonLimpiar.setBounds(107, 402, 117, 29);
		contentPane.add(botonLimpiar);
	}
}
